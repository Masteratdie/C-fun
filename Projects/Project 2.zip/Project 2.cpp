//Aaron Weitekamp, Section 010
//Project 2
//Purpose: Collects grade scores from the user and returns the average score,
//highest score, and lowest score, along with the corresponding letter grades.
//The program also allows the user to curve the overall average score;
//and return the previous mentioned data, curved to meet the new average.
#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <cmath>
#include "FinalGrade.h"
#include "Gradebook.h"

using namespace std;

//The purpose of this function is to find and update the students highest score, and lowest score.
//As well as return the average of the entered scores
double calculateGradebook(const vector<FinalGrade>& gradebook, double& max_score, double& min_score) {
    //intialize variable used to calculate the average
    double avg = 0;

    //sets min_score as the first score for comparison later
    min_score = gradebook.at(0).getScore();

    //finds the min score by iterating through the vector and updating min_score if the score is lower
    for (int i = 0; i < gradebook.size(); i++) {
        if (gradebook.at(i).getScore() < min_score)
            min_score = gradebook.at(i).getScore();

        //finds the max score by iterating through the vector and updating max_score if the score is higher
        if (gradebook[i].getScore() > max_score)
            max_score = gradebook.at(i).getScore();

        //adds all scores in the vector
        avg += gradebook.at(i).getScore();
    }
    //calculates the average by dividing the added scores by the vector size
    avg /= gradebook.size();

    return round(avg);
}


int main()
{
    //declares user input variable, and the gradebook vector used to later store it
    vector<FinalGrade> CS215gradebook;
    double input_score;

    //this loop repeatedly asks the user for input and verifies it valid or not until 'q' or 'Q' is entered
    while (true)
    {
        cout << "Please enter a score for CS215 (type 'Q' or 'q' to quit): " << endl;
        cin >> input_score;

        // check if the user input is invalid
        if (cin.fail())
        {
            string check_input;
            cin.clear();
            cin >> check_input;
            cin.ignore(256, '\n');  //extra and ignore any possible bad input from the input stream

            if (check_input == "Q" || check_input == "q")
                break;
            else {
                cout << "Invalid input, please try again..." << endl;
                continue;
            }
        }

        // check if the input score is in the correct range: [0,100]
        if (input_score < 0 || input_score > 100)
        {
            cout << "The score is not in the correct range, please try again..." << endl;
        }
        else  // valid user input, store into gradeList object
        {
            FinalGrade inputFG(input_score);
            CS215gradebook.push_back(inputFG);
        }

        cin.ignore(256, '\n');  //extra and ignore any possible bad input from the input stream
    }

    // Check if the gradebook is empty
    // If it is empty, report it then quit the program
    if (CS215gradebook.size() == 0)
    {
        cout << "The gradebook for CS215 is empty!" << endl;
        cout << "Thank you for using the Grade Curve Calculator.";
        
        return 1;

    }

    //initalizes the min, max, and average score
    double max_score = 0;
    double min_score = 0;
    double average = calculateGradebook(CS215gradebook, max_score, min_score); //this function calculates not only the average, but also the min and max score using pass by reference

    //creates Gradebook object to store the original gradebook created using the FinalGrade class
    Gradebook CS215gradebook_original;

    //adds all grade scores to gradebook object
    for (int i = 0; i < CS215gradebook.size(); i++)
    {
        FinalGrade stu_FG(CS215gradebook[i]);
        CS215gradebook_original.insert(stu_FG);
    }


    //the purpose of the rest of the program is to allow the user to curve the gradebook if they so wish

    //this loop repeatedly asks the user for input and verifies it valid or not until 'q' or 'Q' is entered,
    //in which case the program ends
    while (true)
    {
        //outputs information and instruction to user
        cout << fixed << setprecision(2);
        cout << "\n\nThe original average score is:\t" << CS215gradebook_original.getAverage();
        cout << "\nThe Grade Curve Calculator can help you reach your expected average score\n";
        cout << "If you are not satisfied with the current average score\n";
        cout << "It is written by Aaron Weitekamp, who can read your mind:)\n";
        cout << "Please enter your expected average score to curve (type 'Q' \nor 'q' to quit): " << endl;

        //collects user input
        double wantedAverage;
        cin >> wantedAverage;

        //intializes variables used to check whether the user input is valid
        double diff = wantedAverage - CS215gradebook_original.getAverage();
        const double EPSILON = 1.0e-2;

        // check if the user input is invalid
        if (cin.fail())
        {
            string check_input;
            cin.clear();
            cin >> check_input;
            cin.ignore(256, '\n');  //extra and ignore any possible bad input from the input stream

            if (check_input == "Q" || check_input == "q")
                break;
            else {
                cout << "Invalid input, please try again..." << endl;
                continue;
            }
        }

        // check if the input score is in the correct range: [0,100]
        if (diff < MIN_SCORE || diff > MAX_SCORE || wantedAverage < MIN_SCORE || wantedAverage > MAX_SCORE)
        {
            cout << "The expected average is not in the correct range, please\ntry again..." << endl;
        }

        else if (abs(diff) < EPSILON)
            cout << "The scores are perfect, no need for the grading curve!" << endl;
        else  // valid user input, store into gradeList object
        {
            //displays the original gradebook information and the new curved gradebook information
            //information includes min, max, and average values, as well as the correspoinding grade
            cout << fixed << setprecision(2);
            cout << endl << endl;
            cout << "The original gradebook for CS215: " << endl;
            CS215gradebook_original.print();
            cout << "The number of scores is:\t" << CS215gradebook_original.getSize() << endl;
            cout << "The maximum score is:\t";
            CS215gradebook_original.getMax().print();
            cout << "The minimum score is:\t";
            CS215gradebook_original.getMin().print();
            cout << "The original average score is:\t" << CS215gradebook_original.getAverage() << endl;


            Gradebook CS215gradebook_curved = CS215gradebook_original;
            CS215gradebook_curved.incrementScore(diff);
            cout << "\nThe expected average score is: " << wantedAverage << endl;
            cout << "The curved gradebook for CS215: " << endl;
            CS215gradebook_curved.print();
            cout << "The number of scores is:\t" << CS215gradebook_curved.getSize() << endl;
            cout << "The maximum score is:\t";
            CS215gradebook_curved.getMax().print();
            cout << "The minimum score is:\t";
            CS215gradebook_curved.getMin().print();
            cout << "The actual average score is:\t" << CS215gradebook_curved.getAverage() << endl;
        }

        cin.ignore(256, '\n');  //extra and ignore any possible bad input from the input stream
    }
    //end the program and thanks the user
    cout << "Thank you for using the Grade Curve Calculator.";
    return 0;
}