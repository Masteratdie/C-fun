//Aaron Weitekamp, Section: 010
//The purpose of this program is to define each function of class gradebook

#include <iostream>
#include <iomanip>
#include <vector>
#include "Gradebook.h"
using namespace std;
const int WIDTH = 6;

// default constructor
Gradebook::Gradebook()
{

}

// return the size of the  current vector: scores,
 // which represents current gradebook
int Gradebook::getSize() const
{
	return scores.size();
}

// inserts a FinalGrade object, newFG, 
// into the end of the current gradebook
void Gradebook::insert(FinalGrade newFG)
{
	scores.push_back(newFG);
}

//returns the max score found in the current gradebook
FinalGrade Gradebook::getMax() const
{
	double max = 0;
	for (int i = 0; i < scores.size(); i++) {
		if (scores.at(i).getScore() > max)
			max = scores.at(i).getScore();
	}

	return max;
}

//returns the max score found in the current gradebook
FinalGrade Gradebook::getMin() const
{
	double min = scores.at(0).getScore();
	for (int i = 0; i < scores.size(); i++) {
		if (scores.at(i).getScore() < min)
			min = scores.at(i).getScore();
	}

	return min;
}

//returns the average score found in the current gradebook
double Gradebook::getAverage() const
{
	double avg = 0;
	for (int i = 0; i < scores.size(); i++) {
		avg += scores.at(i).getScore();
	}
	return avg /= scores.size();

}

//adds the parameter-value to each score of the gradebook
//unless the addition makes the score greater than 100,
//in which case the score is set equal to 100
void Gradebook::incrementScore(double value)
{
	for (int i = 0; i < scores.size(); i++) {
		if (scores.at(i).getScore() + value < MAX_SCORE)
			scores.at(i) = scores.at(i).getScore() + value;
		else
			scores.at(i) = MAX_SCORE;
	}
}

//displays each score in the gradebook with its corresponding letter grade
void Gradebook::print() const
{
	FinalGrade grade;

	for (int i = 0; i < scores.size(); i++) {
		grade = scores.at(i);
		cout << "Score: " << fixed << setprecision(2) << setw(WIDTH) << scores.at(i).getScore() << setw(WIDTH) << grade.decideLetterGrade() << "\n";
	}
}